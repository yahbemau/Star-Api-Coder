function homeController() {
  console.log('cargamos el home')
  $('.main-title').text('star wars api')
}

export default homeController


