

function savedController() {
  console.log('cargamos guaradado')
  $('.main-title').text('cargamos la seccion guardado..')
  setStorage();

}





export default savedController
