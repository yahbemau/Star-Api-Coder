import './router';
import {setStorage, getStorage, startStorage} from './utils/storage'

$(document).ready(function() {
  startStorage();
})
